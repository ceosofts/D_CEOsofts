@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Profile Page</h1>
    <p>Here you can manage your profile details.</p>
</div>
@endsection
